#!/bin/bash

RED="\033[0;31m"
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
NC="\033[0m"

cat /etc/os-release
uname -a
ifconfig
cat /etc/os-release >> $HOSTNAME.thongtin
uname -a >> $HOSTNAME.thongtin
ifconfig  >>$HOSTNAME.thongtin
ip a >>$HOSTNAME.thongtin

echo -e "================================================================================"
echo -e "${GREEN}Ra soat tien trinh${NC}"
echo -e "================================================================================"
ps aux | more
ps aux | more >> $HOSTNAME.thongtin
#centos: ps -a -e -o pid,user,lstart,time,comm,cmd,args
#debian/ubuntu: ps -eo pid,user,lstart,time,comm,cmd,args
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "================================================================================"
echo -e "${GREEN}Ra soat ket noi mang${NC}"
echo -e "================================================================================"

echo -e "${YELLOW}netstat -ntlpu${NC}"
netstat -ntlpu | more
netstat -ntlpu | more >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}netstat -nap${NC}"
netstat -nap | more
netstat -nap | more >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "================================================================================"
echo -e "${GREEN}Ra soat autoruns${NC}"
echo -e "================================================================================"

echo -e "${YELLOW}ls -latr /etc/cron*${NC}"
ls -latr /etc/cron*
ls -latr /etc/cron* >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}ls -latr /home/*/.bashrc${NC}"
ls -latr /home/*/.bashrc
ls -latr /home/*/.bashrc >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}ls -latr /home/*/.bash_profile${NC}"
ls -latr /home/*/.bash_profile
ls -latr /home/*/.bash_profile >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}ls -latr /home/*/.bash_logout${NC}"
ls -latr /home/*/.bash_logout
ls -latr /home/*/.bash_logout >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}ls -latr /etc/profile${NC}"
ls -latr /etc/profile
ls -latr /etc/profile >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}ls -latr /etc/environment${NC}"
ls -latr /etc/environment
ls -latr /etc/environment >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}ls -latr /etc/bashrc${NC}"
ls -latr /etc/bashrc
ls -latr /etc/bashrc >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}ls -latr /etc/init.d/${NC}"
ls -latr /etc/init.d/ | more
ls -latr /etc/init.d/ | more >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}ls -latr /etc/rc*.d/${NC}"
ls -latr /etc/rc*.d/ | more
ls -latr /etc/rc*.d/ | more >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}ls -latr /etc/ssh/sshrc${NC}"
ls -latr /etc/ssh/sshrc
ls -latr /etc/ssh/sshrc >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}ls -latr /etc/xdg/lxsession/Lubuntu/autostart${NC}"
ls -latr /etc/xdg/lxsession/Lubuntu/autostart
ls -latr /etc/xdg/lxsession/Lubuntu/autostart >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}ls -latr /usr/share/autostart${NC}"
ls -latr /usr/share/autostart
ls -latr /usr/share/autostart >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}ls -latr /etc/xdg/xfce4/xinitrc${NC}"
ls -latr /etc/xdg/xfce4/xinitrc
ls -latr /etc/xdg/xfce4/xinitrc >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "================================================================================"
echo -e "${GREEN}Ra soat users${NC}"
echo -e "================================================================================"

echo -e "${YELLOW}cat /etc/passwd${NC}"
cat /etc/passwd
cat /etc/passwd >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}cat /etc/sudoers${NC}"
cat /etc/sudoers
cat /etc/sudoers >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "================================================================================"
echo -e "${GREEN}Ra soat command history${NC}"
echo -e "================================================================================"

echo -e "${YELLOW}cat /var/log/cmdlog.log${NC}"
cat /var/log/cmdlog.log | more
cat /var/log/cmdlog.log | more >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}/home/*/.bash_history${NC}"
cat /home/*/.bash_history | more
cat /home/*/.bash_history | more >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}cat /home/*/.sh_history${NC}"
cat /home/*/.sh_history | more
cat /home/*/.sh_history | more >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}/home/*/.vi_history${NC}"
cat /home/*/.vi_history | more
cat /home/*/.vi_history | more >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "================================================================================"
echo -e "${GREEN}Ra soat log ssh${NC}"
echo -e "================================================================================"

echo -e "${YELLOW}cat /var/log/secure* | grep Accepted${NC}"
cat /var/log/secure* | grep Accepted
cat /var/log/secure* | grep Accepted >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}last${NC}"
last
last >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}lastlog${NC}"
lastlog
lastlog >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "================================================================================"
echo -e "${GREEN}Ra soat thu muc quan trong${NC}"
echo -e "================================================================================"

echo -e "${YELLOW}ls -latr /tmp${NC}"
ls -latr /tmp | more
ls -latr /tmp | more >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "${YELLOW}ls -latr /var/run${NC}"
ls -latr /var/run | more
ls -latr /var/run | more >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "================================================================================"
echo -e "${GREEN}Ra soat tunnel${NC}"
echo -e "================================================================================"
iptables -L -vn -t nat
iptables -L -vn -t nat >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

echo -e "================================================================================"
echo -e "${GREEN}Services${NC}"
echo -e "================================================================================"
service --status-all
service --status-all >> $HOSTNAME.thongtin
echo -e "${YELLOW}Done!${NC}"
read -rsp $'Press ENTER to continue...\n'

read -rsp $'Finish!!!\n'
